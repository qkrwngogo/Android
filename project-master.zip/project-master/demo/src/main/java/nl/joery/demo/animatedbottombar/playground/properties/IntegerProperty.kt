package nl.joery.demo.animatedbottombar.playground.properties

import android.util.TypedValue


class IntegerProperty(name: String, val density: Int = TypedValue.DENSITY_NONE) : Property(name)