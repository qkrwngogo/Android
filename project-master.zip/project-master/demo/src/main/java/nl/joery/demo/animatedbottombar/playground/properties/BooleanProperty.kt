package nl.joery.demo.animatedbottombar.playground.properties


class BooleanProperty(name: String) : Property(name)