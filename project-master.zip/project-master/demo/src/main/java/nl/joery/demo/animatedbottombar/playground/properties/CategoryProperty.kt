package nl.joery.demo.animatedbottombar.playground.properties


class CategoryProperty(name: String) : Property(name)