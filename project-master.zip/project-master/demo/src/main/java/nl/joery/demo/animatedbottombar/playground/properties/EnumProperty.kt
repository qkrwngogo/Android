package nl.joery.demo.animatedbottombar.playground.properties


class EnumProperty(name: String, val enumClass: Class<*>) : Property(name)