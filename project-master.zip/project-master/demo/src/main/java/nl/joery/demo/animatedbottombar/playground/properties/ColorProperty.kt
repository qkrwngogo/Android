package nl.joery.demo.animatedbottombar.playground.properties


class ColorProperty(name: String) : Property(name)